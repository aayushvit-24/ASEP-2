import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

export const listDevices = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("devices").collect();
  },
});

export const getRoutes = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("routes").collect();
  },
});

export const generateRoute = mutation({
  args: {
    start: v.object({
      x: v.number(),
      y: v.number(),
    }),
    end: v.object({
      x: v.number(),
      y: v.number(),
    }),
  },
  handler: async (ctx, args) => {
    // Simple direct path for now
    const path = [args.start, args.end];
    const dx = args.end.x - args.start.x;
    const dy = args.end.y - args.start.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    return await ctx.db.insert("routes", {
      startPoint: args.start,
      endPoint: args.end,
      path,
      distance,
    });
  },
});
