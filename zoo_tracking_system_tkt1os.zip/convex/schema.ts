import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  devices: defineTable({
    name: v.string(),
    location: v.object({
      x: v.number(),
      y: v.number(),
    }),
    animalType: v.string(),
    description: v.string(),
    batteryLevel: v.number(),
    isActive: v.boolean(),
  }),
  routes: defineTable({
    startPoint: v.object({
      x: v.number(),
      y: v.number(),
    }),
    endPoint: v.object({
      x: v.number(),
      y: v.number(),
    }),
    path: v.array(v.object({
      x: v.number(),
      y: v.number(),
    })),
    distance: v.number(),
  })
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
