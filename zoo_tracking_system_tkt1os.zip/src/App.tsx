import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useEffect, useRef, useState } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Zoo Navigator</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-6xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const devices = useQuery(api.devices.listDevices) || [];
  const routes = useQuery(api.devices.getRoutes) || [];
  const generateRoute = useMutation(api.devices.generateRoute);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedStart, setSelectedStart] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!canvasRef.current || !devices.length) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, 800, 600);
    
    // Draw routes
    routes.forEach(route => {
      ctx.beginPath();
      ctx.moveTo(route.startPoint.x, route.startPoint.y);
      route.path.forEach(point => {
        ctx.lineTo(point.x, point.y);
      });
      ctx.strokeStyle = '#2196F3';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    // Draw devices
    devices.forEach(device => {
      ctx.beginPath();
      ctx.arc(device.location.x, device.location.y, 10, 0, 2 * Math.PI);
      ctx.fillStyle = device.isActive ? '#4CAF50' : '#FF5252';
      ctx.fill();
      
      // Draw labels
      ctx.font = '14px Arial';
      ctx.fillStyle = '#000';
      ctx.fillText(device.name, device.location.x + 15, device.location.y);
    });
  }, [devices, routes]);

  const handleCanvasClick = async (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (!selectedStart) {
      setSelectedStart({ x, y });
    } else {
      await generateRoute({
        start: selectedStart,
        end: { x, y },
      });
      setSelectedStart(null);
    }
  };

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Zoo Navigator</h1>
        <Authenticated>
          <div className="flex flex-col items-center gap-4">
            <p className="text-xl text-slate-600">
              Welcome, {loggedInUser?.email ?? "visitor"}!
            </p>
            <div className="border rounded-lg p-4 bg-white shadow-lg">
              <p className="text-sm text-gray-500 mb-2">
                {selectedStart ? 'Click destination point' : 'Click starting point'} to generate a route
              </p>
              <canvas 
                ref={canvasRef}
                width={800}
                height={600}
                className="border rounded cursor-pointer"
                onClick={handleCanvasClick}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full">
              {devices.map(device => (
                <div key={device._id} className="p-4 border rounded-lg bg-white shadow">
                  <h3 className="font-bold">{device.name}</h3>
                  <p className="text-gray-600">{device.animalType}</p>
                  <p className="text-sm">{device.description}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${device.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                    <span className="text-sm text-gray-500">
                      {device.isActive ? 'Active' : 'Inactive'}
                    </span>
                    <span className="text-sm text-gray-500 ml-auto">
                      Battery: {device.batteryLevel}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to start exploring</p>
          <SignInForm />
        </Unauthenticated>
      </div>
    </div>
  );
}
